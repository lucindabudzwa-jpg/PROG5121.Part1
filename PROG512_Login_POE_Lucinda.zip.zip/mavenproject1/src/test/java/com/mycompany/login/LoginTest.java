package com.mycompany.login;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/*
 * JUnit Tests for POE Part 1
 */
public class LoginTest {

    /*
     * Test: Username correctly formatted
     * Condition: contains "_" and <= 5 characters
     */
    @Test
    public void testUsernameCorrect() {
        boolean result = Main.checkUserName("kyl_1");
        assertTrue(result);
    }

    /*
     * Test: Username incorrectly formatted
     */
    @Test
    public void testUsernameIncorrect() {
        boolean result = Main.checkUserName("kyle!!!!!!!");
        assertFalse(result);
    }

    /*
     * Test: Password meets complexity requirements
     */
    @Test
    public void testPasswordCorrect() {
        boolean result = Main.checkPasswordComplexity("Ch&sec@ke99!");
        assertTrue(result);
    }

    /*
     * Test: Password does NOT meet complexity requirements
     */
    @Test
    public void testPasswordIncorrect() {
        boolean result = Main.checkPasswordComplexity("password");
        assertFalse(result);
    }

    /*
     * Test: Cell phone correctly formatted
     */
    @Test
    public void testPhoneCorrect() {
        boolean result = Main.checkCellPhoneNumber("+27838968976");
        assertTrue(result);
    }

    /*
     * Test: Cell phone incorrectly formatted
     */
    @Test
    public void testPhoneIncorrect() {
        boolean result = Main.checkCellPhoneNumber("0896653");
        assertFalse(result);
    }

    /*
     * Test: Successful login
     */
    @Test
    public void testLoginSuccess() {

        // First register user
        Main.registerUser("kyl_1", "Ch&sec@ke99!", "+27838968976");

        // Then attempt login
        boolean result = Main.loginUser("kyl_1", "Ch&sec@ke99!");

        assertTrue(result);
    }

    /*
     * Test: Failed login
     */
    @Test
    public void testLoginFail() {

        // Register correct user
        Main.registerUser("kyl_1", "Ch&sec@ke99!", "+27838968976");

        // Try wrong password
        boolean result = Main.loginUser("kyl_1", "wrongPass");

        assertFalse(result);
    }

    /*
     * Test: Username correctly formatted (True expected)
     */
    @Test
    public void testUsernameTrue() {
        assertTrue(Main.checkUserName("kyl_1"));
    }

    /*
     * Test: Login Status Message
     */
    @Test
    public void testLoginStatusMessage() {
        String message = Main.returnLoginStatus(true, "kyl_1");
        assertEquals("Welcome kyl_1, it is great to see you again.", message);
    }
}