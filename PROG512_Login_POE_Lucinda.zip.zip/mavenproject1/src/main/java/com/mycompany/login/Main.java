package com.mycompany.login;

import java.util.Scanner;
import java.util.regex.Pattern;

/*
 * POE PART 1 - Registration and Login Feature
 * Console-based application (NO GUI as required)
 */
public class Main {

    // Stored user details (simulate database)
    static String storedUsername;
    static String storedPassword;
    static String storedPhone;

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.println("===== REGISTRATION =====");

        // --- USER INPUT ---
        System.out.print("Enter username: ");
        String username = input.nextLine();

        System.out.print("Enter password: ");
        String password = input.nextLine();

        System.out.print("Enter cell phone number (include +27): ");
        String phone = input.nextLine();

        // --- REGISTER USER ---
        String registerMessage = registerUser(username, password, phone);
        System.out.println(registerMessage);

        // --- LOGIN SECTION ---
        System.out.println("\n===== LOGIN =====");

        System.out.print("Enter username: ");
        String loginUser = input.nextLine();

        System.out.print("Enter password: ");
        String loginPass = input.nextLine();

        boolean loginSuccess = loginUser(loginUser, loginPass);

        // --- LOGIN STATUS MESSAGE ---
        System.out.println(returnLoginStatus(loginSuccess, loginUser));

    }

    /*
     * Method: checkUserName
     * This method ensures that any username contains an underscore (_)
     * and is no more than five characters long.
     */
    public static boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    /*
     * Method: checkPasswordComplexity
     * Password must:
     * - Be at least 8 characters
     * - Contain a capital letter
     * - Contain a number
     * - Contain a special character
     */
    public static boolean checkPasswordComplexity(String password) {

        boolean length = password.length() >= 8;
        boolean capital = Pattern.compile("[A-Z]").matcher(password).find();
        boolean number = Pattern.compile("[0-9]").matcher(password).find();
        boolean special = Pattern.compile("[^a-zA-Z0-9]").matcher(password).find();

        return length && capital && number && special;
    }

    /*
     * Method: checkCellPhoneNumber
     * Must:
     * - Start with +27 (South Africa international code)
     * - Be no more than 12 characters total
     */
    public static boolean checkCellPhoneNumber(String phone) {
        return phone.startsWith("+27") && phone.length() <= 12;
    }

    /*
     * Method: registerUser
     * Returns messages depending on validation results
     */
    public static String registerUser(String username, String password, String phone) {

        if (!checkUserName(username)) {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }

        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }

        if (!checkCellPhoneNumber(phone)) {
            return "Cell phone number incorrectly formatted or does not contain international code; please correct the number and try again.";
        }

        // Save user details
        storedUsername = username;
        storedPassword = password;
        storedPhone = phone;

        return "User successfully registered.";
    }

    /*
     * Method: loginUser
     * Checks if entered login details match stored details
     */
    public static boolean loginUser(String username, String password) {
        return username.equals(storedUsername) && password.equals(storedPassword);
    }

    /*
     * Method: returnLoginStatus
     * Returns appropriate login message
     */
    public static String returnLoginStatus(boolean success, String username) {

        if (success) {
            return "Welcome " + username + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}